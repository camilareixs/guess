function soma() {
    const aleatorio = Math.floor(Math.random() * 100);
    console.log(aleatorio);
    const usuario = parseInt(document.getElementById("numeroUsuario").value);
    const respostaElement = document.getElementById("resposta");
    const chutesElement = document.getElementById("chutes");

    if (usuario === aleatorio) {
        respostaElement.innerHTML = "Parabéns! Você acertou!";
        respostaElement.className = "acertou";
    } else if (usuario > aleatorio) {
        respostaElement.innerHTML = "Oops! Esse número é maior.";
        respostaElement.className = "maior";
    } else {
        respostaElement.innerHTML = "Oops! Esse número é menor.";
        respostaElement.className = "menor";
    }

    const chuteElement = document.createElement("div");
    chuteElement.textContent = usuario;
    chuteElement.classList.add("chute");
    chutesElement.appendChild(chuteElement);
}

window.addEventListener("DOMContentLoaded", function() {
    const canvas = document.getElementById("canvas");
    const context = canvas.getContext("2d");

    // Configurar o tamanho do canvas
    const size = Math.min(window.innerWidth, window.innerHeight) * 0.8;
    canvas.width = size;
    canvas.height = size;

    // Desenhar o conteúdo do canvas aqui
});
